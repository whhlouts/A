package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Mapper
@Component(value = "StudentDao")
public interface StudentDao {

    public void createAccountS(String account, String password, String name, String gender, String university, String executeClassID, String personID, String img, String role);

    //登录
    public Student loginCallS(@Param("account") String account, @Param("password") String password);

    //    获得所有加入的课程
    public List<Course> getAllJoinedCourses(@Param("studentID") String studentID);

    //    加入新课程
    public void studentJoinCourse(CourseStudent courseStudent);

    //   退出课程
    public void quitCourse(CourseStudent courseStudent);

    //    更新个人信息，包括密码等
    public void updateMyInfo(Student student);

    //    获得个人信息
    public Student getMyInfo(@Param("studentID") String studentID);


}
