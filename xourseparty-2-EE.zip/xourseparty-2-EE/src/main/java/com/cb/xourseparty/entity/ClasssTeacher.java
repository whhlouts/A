package com.cb.xourseparty.entity;

/**
 * 课程教师类
 */
public class ClasssTeacher {

    private String classsTeacherID;
    private String courseID;
    private String classsID;
    private String teacherID;
    private String classsRole;
    private Boolean isQuited;
    private String joinDate;

    public ClasssTeacher(String classsTeacherID, String courseID, String classsID, String teacherID, String joinDate, String classsRole, Boolean isQuited) {
        this.classsTeacherID = classsTeacherID;
        this.classsID = classsID;
        this.courseID = courseID;
        this.teacherID = teacherID;
        this.classsRole = classsRole;
        this.isQuited = isQuited;
        this.joinDate = joinDate;
    }

    public ClasssTeacher() {
    }

    public String getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(String joinDate) {
        this.joinDate = joinDate;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getClasssTeacherID() {
        return classsTeacherID;
    }

    public void setClasssTeacherID(String classsTeacherID) {
        this.classsTeacherID = classsTeacherID;
    }

    public String getClasssID() {
        return classsID;
    }

    public void setClasssID(String classsID) {
        this.classsID = classsID;
    }

    public String getTeacherID() {
        return teacherID;
    }

    public void setTeacherID(String teacherID) {
        this.teacherID = teacherID;
    }

    public String getClasssRole() {
        return classsRole;
    }

    public void setClasssRole(String classsRole) {
        this.classsRole = classsRole;
    }

    public Boolean getQuited() {
        return isQuited;
    }

    public void setQuited(Boolean quited) {
        isQuited = quited;
    }
}
