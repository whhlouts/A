package com.cb.xourseparty.service;

import com.cb.xourseparty.dao.*;
import com.cb.xourseparty.entity.*;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class TeacherServiceImpl implements TeacherService {
    //    		§ Classs =CL
    //			§ classsTeacher = CT
    //			§ Course = CO
    //			§ courseStudent = CS
    //			§ Notice = NT
    //			§ Resource = RS
    //			§ studentTask = ST
    //          § task=TK
    @Autowired
    private TeacherDao teacherDao;
    @Autowired
    private ClasssDao classsDao;
    @Autowired
    private ClasssTeacherDao classsTeacherDao;
    @Autowired
    private CourseDao courseDao;
    @Autowired
    private CourseStudentDao courseStudentDao;
    @Autowired
    private NoticeDao noticeDao;
    @Autowired
    private ResourceDao resourceDao;
    @Autowired
    private StudentTaskDao studentTaskDao;
    @Autowired
    private TaskDao taskDao;

    @Autowired
    private InfoService infoService;

    /**
     * 新建账户
     *
     * @param account
     * @param password
     * @param name
     * @param gender
     * @param university
     * @param faculty
     * @param personID
     * @param img
     * @param role
     */
    @Override
    public void createAccountT(String account, String password, String name, String gender, String university, String faculty, String personID, String img, String role) {
        teacherDao.createAccountT(account, password, name, gender, university, faculty, personID, img, role);
    }

    /**
     * 教师登录
     *
     * @param account
     * @param password
     * @return
     */
    @Override
    public Teacher loginCallT(String account, String password) {
        return teacherDao.loginCallT(account,password);
    }

    /**
     * 获得所有加入的课程
     *
     * @param account
     * @return
     */
    @Override
    public List<Course> getTeacherJoinedCourses(String account) {
        return teacherDao.getTeacherJoinedCoursesByTeacherID(account);
    }

    /**
     * 获得按学期分类的课程
     *
     * @param account
     * @return
     */
    @Override
    public Map<String, List<Course>> getTeacherJoinedCoursesByTerm(String account) {
        List<Course> courses = teacherDao.getTeacherJoinedCoursesByTeacherID(account);
        Map<String, List<Course>> courseListMap = new LinkedHashMap<>();
        String[] terms = new String[10];
        for (Course course : courses) {
//            String courseTerm = course.getCourseTerm();
//            int index = -1;
//            for (int i = 0; i < terms.length; i++) {
//                if (terms[i].equals(courseTerm)) {
//                    index = i;
//                }
//            }
//            if (index == -1) {
//                courseListMap.put(courseTerm, new ArrayList<>());
//                courseListMap.get(courseTerm).add(course);
//            } else {
//                courseListMap.get(courseTerm).add(course);
//            }
            if (courseListMap.get(course.getCourseTerm()) == null) {
                List<Course> list = new ArrayList<>();
                list.add(course);
                courseListMap.put(course.getCourseTerm(), list);
            } else {
                courseListMap.get(course.getCourseTerm()).add(course);
            }
        }
        return courseListMap;
    }

    /**
     * 获得最近的课程
     *
     * @param account
     * @return
     */
    @Override
    public List<Course> getTeacherRecentJoinedCourses(String account) {
//        最近课程的显示数量
        int recentSize = 4;
        List<Course> recentCourses = new ArrayList<>();
        List<Course> courses = teacherDao.getTeacherJoinedCoursesByTeacherID(account);
        if (courses.size() <= recentSize) {
            return courses;
        } else {
            for (int i = 0; i < recentSize; i++) {
                recentCourses.add(courses.remove(courses.size() - 1));
            }
        }
        return recentCourses;
    }

    /**
     * 加入新课程
     *
     * @param courseCode
     * @param account
     */
    @Override
    public void teacherJoinCourse(String courseCode, String account) {
        Course course = courseDao.getCourseByCode(courseCode);
        ClasssTeacher classsTeacher = classsTeacherDao.getClasssTeacherByIDS(course.getCourseID(), account);
        if (classsTeacher == null) {
            String classsTeacherID = "CT" + RandomStringUtils.randomAlphabetic(10);
            Classs classs = classsDao.getClasssByCourseID(course.getCourseID());
            String joinDate = generateDate();
            ClasssTeacher classsTeachera = new ClasssTeacher(classsTeacherID, course.getCourseID(), classs.getClasssID(), account, joinDate, "助教", false);
//            teacherDao.teacherJoinCourse(classsTeachera);
            classsTeacherDao.createNewClasssTeacher(classsTeachera);
        } else {
            classsTeacher.setQuited(false);
            classsTeacherDao.updateClasssTeacherStatue(classsTeacher);
        }


    }

    /**
     * 创建新课程
     *
     * @param courseName
     * @param courseTerm
     * @return
     */
    @Override
    public void createNewCourse(String courseName, String courseTerm, String account) {
        String courseID = "CO" + RandomStringUtils.randomAlphabetic(10);
        String classsID = "CL" + RandomStringUtils.randomAlphabetic(10);
        String classsTeacherID = "CT" + RandomStringUtils.randomAlphabetic(10);
        String joinCode = "JC" + RandomStringUtils.randomAlphabetic(4);
        Teacher teacher = teacherDao.getTeacherByID(account);
        Course course = new Course(courseID, courseName, "未填写", teacher.getUniversity(), teacher.getFaculty(), courseTerm, "", joinCode, account, teacher.getImg(), teacher.getName());
        courseDao.createNewCourse(course);
        Classs classs = new Classs(classsID, course.getCourseID(), 0);
        classsDao.createNewClasss(classs);
        ClasssTeacher classsTeacher = new ClasssTeacher(classsTeacherID, courseID, classsID, account, generateDate(), "管理员", false);
        classsTeacherDao.createNewClasssTeacher(classsTeacher);


    }

    /**
     * 修改课程基本信息
     *
     * @param courseID
     * @param courseName
     * @param courseTerm
     * @param courseFaulty
     * @param courseIntro
     * @return
     */
    @Override
    public Course updateCourseInfo(String courseID, String courseName, String courseTerm, String courseFaulty, String courseIntro) {
        Course c = courseDao.getCourseByID(courseID);
        Course course = new Course(courseID, courseName, courseIntro, c.getCourseUniversity(), courseFaulty, courseTerm, c.getCourseType(), c.getCourseJoinCode(), c.getCourseAdminID(), c.getCourseAdminImg(), c.getCourseAdminName());
        courseDao.updateCourseInfo(course);
        return course;
    }

    /**
     * 退出课程
     *
     * @param courseID
     * @param account
     */
    @Override
    public void quitCourse(String courseID, String account) {
        ClasssTeacher classsTeacher = classsTeacherDao.getClasssTeacherByIDS(courseID, account);
        classsTeacher.setQuited(true);
        teacherDao.quitCourse(classsTeacher);
    }

    /**
     * 获得按学生分类的学生成绩表
     *
     * @param courseID
     * @return
     */
    @Override
    public Map<Student, List<StudentTask>> getAllStudentsTasks(String courseID) {
        List<Student> students = courseDao.getCoursesStudents(courseID);
        Map<Student, List<StudentTask>> studentListMap = new LinkedHashMap<>();
        for (Student student : students) {
            studentListMap.put(student, studentTaskDao.getCertainStudentsStudentTasksByCourseID(courseID, student.getAccount()));
        }
        return studentListMap;
    }

    /**
     * 创建作业
     *
     * @param courseID     目标课程
     * @param taskName
     * @param taskType
     * @param taskDeadLine
     * @param taskIntro
     * @param taskFile
     * @return
     */
    @Override
    public void createNewTask(String courseID, String taskName, String taskType, String taskDeadLine, String taskIntro, String taskFile, Integer taskTotalScore) {
//        文件地址有问题
        String taskID = "TK" + RandomStringUtils.randomAlphabetic(10);
        Classs classs = classsDao.getClasssByCourseID(courseID);
        String taskCreateDate = generateDate();
        Task task = new Task(taskID, courseID, taskName, taskIntro, taskType, taskCreateDate, taskDeadLine, classs.getCountStudent(), 0, classs.getCountStudent(), 0, 0, taskFile, taskTotalScore);
        taskDao.createNewTask(task);

        List<Student> studentsInThisCourse = courseDao.getCoursesStudents(courseID);
        for (Student student : studentsInThisCourse) {
            String studentTaskID = "ST" + RandomStringUtils.randomAlphabetic(10);
            Notice notice = new Notice("NT" + RandomStringUtils.randomAlphabetic(10), "您有新作业提醒！", "课程已发布新作业", "课程：" + courseDao.getCourseByID(courseID).getCourseName() + "，已发布新作业：" + task.getTaskName() + " ", taskID, taskName, courseID, courseDao.getCourseByID(courseID).getCourseName(), student.getAccount(), false, generateDate());
            StudentTask studentTask = new StudentTask(studentTaskID, "", "", 0.0, "type", "", false, student.getAccount(), student.getPersonID(), student.getName(), taskID, taskName, taskTotalScore, courseID, courseDao.getCourseByID(courseID).getCourseName(), false, 0, "", "", "");
            noticeDao.createNotice(notice);
            studentTaskDao.createNewStudentTask(studentTask);
        }

        infoService.updateCourseNumber(courseID);
    }

    /**
     * 更新作业基本信息
     *
     * @param taskID
     * @param taskName
     * @param taskType
     * @param taskDeadLine
     * @param taskIntro
     * @param taskFile
     * @return
     */
    @Override
    public void updateTaskInfo(String taskID, String taskName, String taskType, String taskDeadLine, String taskIntro, String taskFile, Integer taskTotalScore) {
        Task task = taskDao.getTaskByTaskID(taskID);
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String taskCreateDate = formatter.format(date);
        Task newTask = new Task(task.getTaskID(), task.getCourseID(), taskName, taskIntro, taskType, taskCreateDate, taskDeadLine, task.getTaskNumberShouldSubmit(), task.getTaskNumberHaveSubmit(), task.getTaskNumberNotYetSubmit(), task.getTaskNumberHaveChecked(), task.getTaskNumberNotYetChecked(), taskFile, taskTotalScore);
        taskDao.updateTaskInfo(newTask);

        List<Student> studentsInThisCourse = courseDao.getCoursesStudents(task.getCourseID());
        for (Student student : studentsInThisCourse) {
            Notice notice = new Notice("NT" + RandomStringUtils.randomAlphabetic(10), "您的课程作业信息被更新！", "课程已更新作业信息", "课程：" + courseDao.getCourseByID(task.getCourseID()).getCourseName() + "，已更新作业信息：" + task.getTaskName() + " ", taskID, taskName, task.getCourseID(), courseDao.getCourseByID(task.getCourseID()).getCourseName(), student.getAccount(), false, generateDate());
            noticeDao.createNotice(notice);
//            String studentTaskID = "ST" + RandomStringUtils.randomAlphabetic(10);
//            StudentTask studentTask = new StudentTask(studentTaskID, "studentTaskName", "fileName", 0.0, "type", "", false, student.getAccount(), student.getPersonID(), student.getName(), taskID, taskName, taskTotalScore, task.getCourseID(), courseDao.getCourseByID(task.getCourseID()).getCourseName(), false, 0, "", "teacherID", "teacherName");
//            studentTaskDao.createNewStudentTask(studentTask);
        }
    }

    /**
     * 批改学生作业
     *
     * @param account        批改人
     * @param teacherComment 评语
     */
    @Override
    public void markStudentTask(String studentTaskID, Integer grade, String account, String teacherComment) {
        StudentTask studentTask = studentTaskDao.getStudentTaskByID(studentTaskID);
        studentTask.setMarkerTeacherID(account);
        studentTask.setStudentTaskGrade(grade);
        studentTask.setTeacherComment(teacherComment);
        studentTask.setStudentTaskIsChecked(true);
        studentTask.setMarkerTeacherName(teacherDao.getTeacherByID(account).getName());
        studentTaskDao.updateStudentTask(studentTask);

        Task task = taskDao.getTaskByTaskID(studentTask.getTaskID());
        task.setTaskNumberHaveChecked(task.getTaskNumberHaveChecked() + 1);
        task.setTaskNumberNotYetChecked(task.getTaskNumberNotYetChecked() - 1);
        taskDao.updateTaskInfo(task);

        Notice notice = new Notice("NT" + RandomStringUtils.randomAlphabetic(10), "您的作业被批改！", "作业被批改", "课程：" + courseDao.getCourseByID(task.getCourseID()).getCourseName() + "，作业已被批改：" + task.getTaskName() + " ", task.getTaskID(), task.getTaskName(), task.getCourseID(), courseDao.getCourseByID(task.getCourseID()).getCourseName(), account, false, generateDate());
        noticeDao.createNotice(notice);

        infoService.updateTaskNumbers(task.getTaskID());

    }

    /**
     * 打回学生作业
     *
     * @param courseID
     * @param taskID
     * @param studentID
     * @param studentTaskID
     */
    @Override
    public void sendBackStudentTask(String courseID, String taskID, String studentID, String studentTaskID) {
        StudentTask studentTask = studentTaskDao.getStudentTaskByID(studentTaskID);
        studentTask.setStudentTaskIsChecked(false);
        studentTask.setStudentTaskIsSentBack(true);
        studentTask.setStudentTaskFile("");
        studentTask.setTeacherComment("");
        studentTask.setStudentTaskGrade(0);
        studentTask.setMarkerTeacherName("");
        studentTask.setMarkerTeacherID("");
        studentTaskDao.updateStudentTask(studentTask);

        Notice notice = new Notice("NT" + RandomStringUtils.randomAlphabetic(10), "您的作业被打回！", "作业被打回", "课程：" + studentTask.getCourseName() + "，作业已被打回：" + studentTask.getTaskName() + " ", studentTask.getTaskID(), studentTask.getTaskName(), studentTask.getCourseID(), studentTask.getCourseName(), studentTask.getStudentID(), false, generateDate());
        noticeDao.createNotice(notice);

        infoService.updateTaskNumbers(taskID);
    }

    /**
     * 更新个人信息
     *
     * @param account
     * @param personID
     * @param name
     * @param gender
     * @param university
     * @param faculty
     * @param role
     * @param password
     * @param img
     */
    @Override
    public void updateMyInfo(String account, String personID, String name, String gender, String university, String faculty, String role, String password, String img) {
        Teacher teacher = teacherDao.getMyInfo(account);
        teacher.setPersonID(personID);
        teacher.setFaculty(faculty);
        teacher.setGender(gender);
        teacher.setImg(img);
        teacher.setName(name);
        teacher.setUniversity(university);
        teacher.setRole(role);
        teacher.setPassword(password);
        teacherDao.updateMyInfo(teacher);
    }


    /**
     * 创建新课程资料
     *
     * @param courseID
     * @param resourceName
     * @param resourceType
     * @param resourceIntro
     * @param resourceFile
     */
    @Override
    public void createNewResource(String courseID, String resourceName, String resourceType, String resourceIntro, String resourceFile, String account) {
        String createDate = generateDate();
        String resourceID = "RS" + RandomStringUtils.randomAlphabetic(10);
        Resource resource = new Resource(resourceID, courseID, resourceName, account, createDate, resourceIntro, resourceFile, 0);
        resourceDao.createNewResource(resource);
    }

    /**
     * 更新课程资料信息
     *
     * @param resourceID
     * @param resourceName
     * @param resourceIntro
     * @param resourceFile
     */
    @Override
    public void updateResource(String resourceID, String resourceName, String resourceIntro, String resourceFile, String account) {
        Resource resource = resourceDao.getResourceByID(resourceID);
        resource.setResourceAuthor(account);
        resource.setResourceCreateDate(generateDate());
        resource.setResourceIntro(resourceIntro);
        resource.setResourceName(resourceName);
        resource.setResourceFile(resourceFile);
        resourceDao.updateResource(resource);
    }

    /**
     * 查看个人信息
     *
     * @param account
     * @return teacher
     */
    @Override
    public Teacher getMyInfo(String account) {
        return teacherDao.getMyInfo(account);
    }

    /**
     * 将教师从课程移除
     *
     * @param courseID
     * @param teacherTargetAccount
     */
    @Override
    public void removeTeacherFromCourse(String courseID, String teacherTargetAccount) {
        ClasssTeacher classsTeacher = classsTeacherDao.getClasssTeacherByIDS(courseID, teacherTargetAccount);
        classsTeacher.setQuited(true);
        classsTeacherDao.updateClasssTeacherStatue(classsTeacher);
    }

    /**
     * 将学生从课程移除
     *
     * @param courseID
     * @param studentTargetAccount
     */
    @Override
    public void removeStudentFromCourse(String courseID, String studentTargetAccount) {
        CourseStudent courseStudent = courseStudentDao.getCourseStudentByIDS(courseID, studentTargetAccount);
        courseStudent.setQuited(true);
        courseStudentDao.updateCourseStudentStatue(courseStudent);
    }

    /**
     * 催交作业
     *
     * @param studentID
     * @param taskID
     */
    @Override
    public void urgeStudentToSubmitTask(String studentID, String taskID, String courseID) {
        Notice notice = new Notice("NT" + RandomStringUtils.randomAlphabetic(10),
                "催交作业", "URGE", "催交作业", taskID, taskDao.getTaskByTaskID(taskID).getTaskName(), courseID, courseDao.getCourseByID(courseID).getCourseName(), studentID, false, generateDate());
        noticeDao.createNotice(notice);
    }

    /**
     * 上传资源
     *
     * @param questionImages
     * @param resourceID
     */
    @Override
    public void updateResourceFile(MultipartFile[] questionImages, String resourceID) {
//        Map<String,Object> map = new HashMap<String,Object>();
//        List<ImgDetail> listImgDetail = new ArrayList<ImgDetail>();
//        try {
//            for(MultipartFile file:questionImages){
//                String fileName = file.getOriginalFilename();
//                InputStream fileStrem = file.getInputStream();
//                String fileUrl = AliyunOSSUtil.uploadStemImage(fileStrem,fileName);
//                if(!Constants.RESULT_ERROR.equals(fileUrl)){
//                    listImgDetail.add(imgDetail);
//                }
//            }
//            // 将上传成功图片全部添加到数据库中
//            Result result = imgGroupManage.insertImgDetail(listImgDetail);
//            // 图片插入结果
//            if((Constants.RESULT_OK).equals(result.getResult())){
//                map.put("code",Constants.RESULT_OK);
//                map.put("data",listImgDetail);
//            }else{
//                map.put("code",Constants.RESULT_ERROR);
//            }
//        } catch (IOException e) {
//            map.put("code", Constants.RESULT_ERROR);
//            log.error(e.getMessage());
//        }
//        return map;
    }

    private String generateDate() {
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String strDate = formatter.format(date);
        return strDate;
    }
}
