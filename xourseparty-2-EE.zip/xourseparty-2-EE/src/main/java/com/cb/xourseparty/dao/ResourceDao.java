package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.Resource;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component(value = "ResourceDao")
public interface ResourceDao {
    //    获得所有课程资料
    public List<Resource> getAllResources(@Param("courseID") String courseID);

    //    创建新课程资料
    public void createNewResource(Resource resource);

    //    更新课程资料信息
    public void updateResource(Resource resource);

    //    根据ID获得resource
    public Resource getResourceByID(@Param("resourceID") String resourceID);

}
