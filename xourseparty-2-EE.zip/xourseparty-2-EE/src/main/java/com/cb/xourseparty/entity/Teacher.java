package com.cb.xourseparty.entity;

/**
 * 教师类
 */
public class Teacher {

    private String account;
    private String personID;
    private String name;
    private String gender;
    private String university;
    private String faculty;
    private String role;
    private String password;
    private String img;

    public Teacher(String account, String personID, String name, String gender, String university, String faculty, String role, String password, String img) {
        this.account = account;
        this.personID = personID;
        this.name = name;
        this.gender = gender;
        this.university = university;
        this.faculty = faculty;
        this.role = role;
        this.password = password;
        this.img = img;
    }

    public Teacher() {
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public String getPersonID() {
        return personID;
    }

    public void setPersonID(String personID) {
        this.personID = personID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getUniversity() {
        return university;
    }

    public void setUniversity(String university) {
        this.university = university;
    }

    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }
}
