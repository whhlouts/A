package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.Task;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component(value = "TaskDao")
public interface TaskDao {
    //    获得所有作业
    public List<Task> getAllTasks(@Param("courseID") String courseID);

    //    根据ID获得Task
    public Task getTaskByTaskID(@Param("taskID") String taskID);

    //    创建作业
    public void createNewTask(Task task);

    //    更新作业信息
    public void updateTaskInfo(Task task);
}
