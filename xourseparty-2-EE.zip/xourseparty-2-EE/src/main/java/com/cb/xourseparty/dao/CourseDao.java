package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Mapper
@Component(value = "CourseDao")
public interface CourseDao {
    //    创建课程
    public void createNewCourse(Course newCourse);

    //    根据ID获得课程
    public Course getCourseByID(@Param("courseID") String courseID);

    //    根据joinCode得到课程
    public Course getCourseByCode(@Param("courseJoinCode") String courseJoinCode);

    //    获得课程的学生列表
    public List<Student> getCoursesStudents(@Param("courseID") String courseID);

    //    获得课程的教师列表
    public List<ClasssTeacher> getClasssTeachers(@Param("courseID") String courseID);

    public List<Teacher> getCoursesTeachers(@Param("courseID") String courseID);

    //    修改课程基本信息
    public void updateCourseInfo(Course course);

//    //    新增教师成员的反操作
//    public void removeTeacherFromCourseMember(String courseID, String teacherTargetAccount);
//
//    //    新增学生成员的反操作
//    public void removeStudentFromCourseMember(String courseID, String studentTargetAccount);


}
