package com.cb.xourseparty.service;


import com.cb.xourseparty.entity.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;
import java.util.Map;

public interface TeacherService {

    /**
     * 新建账户
     *
     * @param account
     * @param password
     * @param name
     * @param gender
     * @param university
     * @param faculty
     * @param personID
     * @param img
     * @param role
     */
    @Transactional
    public void createAccountT(String account, String password, String name, String gender, String university, String faculty, String personID, String img, String role);

    /**
     * 教师登录
     *
     * @param account
     * @param password
     * @return
     */
    @Transactional
    public Teacher loginCallT(String account, String password);

    /**
     * 获得所有加入的课程
     *
     * @param account
     * @return
     */
    @Transactional
    public List<Course> getTeacherJoinedCourses(String account);


    /**
     * 获得按学期分类的课程
     *
     * @param account
     * @return
     */
    @Transactional
    public Map<String, List<Course>> getTeacherJoinedCoursesByTerm(String account);

    /**
     * 获得最近的课程
     *
     * @param account
     * @return
     */
    @Transactional
    public List<Course> getTeacherRecentJoinedCourses(String account);


    /**
     * 加入新课程
     *
     * @param courseCode
     * @param account
     */
    @Transactional
    public void teacherJoinCourse(String courseCode, String account);

    /**
     * 创建新课程
     *
     * @param courseName
     * @param courseTerm
     * @return
     */
    @Transactional
    public void createNewCourse(String courseName, String courseTerm, String account);


    /**
     * 修改课程基本信息
     *
     * @param courseID
     * @param courseName
     * @param courseTerm
     * @param courseFaulty
     * @param courseIntro
     * @return
     */
    @Transactional
    public Course updateCourseInfo(String courseID, String courseName, String courseTerm, String courseFaulty, String courseIntro);

    /**
     * 退出课程
     *
     * @param courseID
     * @param account
     */
    @Transactional
    public void quitCourse(String courseID, String account);

    /**
     * 获得按学生分类的学生成绩表
     *
     * @param courseID
     * @return
     */
    @Transactional
    public Map<Student, List<StudentTask>> getAllStudentsTasks(String courseID);

    /**
     * 创建作业
     *
     * @param courseID     目标课程
     * @param taskName
     * @param taskType
     * @param taskDeadLine
     * @param taskIntro
     * @param taskFile
     * @return
     */
    @Transactional
    public void createNewTask(String courseID, String taskName, String taskType, String taskDeadLine, String taskIntro, String taskFile, Integer taskTotalScore);

    /**
     * 更新作业基本信息
     *
     * @param taskID
     * @param taskFile
     * @param taskName
     * @param taskType
     * @param taskDeadLine
     * @param taskIntro
     * @return
     */
    @Transactional
    public void updateTaskInfo(String taskID, String taskName, String taskType, String taskDeadLine, String taskIntro, String taskFile, Integer taskTotalScore);


    /**
     * 批改学生作业
     *
     * @param account        批改人
     * @param teacherComment 评语
     */
    @Transactional
    public void markStudentTask(String studentTaskID, Integer grade, String account, String teacherComment);

    /**
     * 打回学生作业
     *
     * @param courseID
     * @param taskID
     * @param studentID
     * @
     */
    @Transactional
    public void sendBackStudentTask(String courseID, String taskID, String studentID, String studentTaskID);

    /**
     * 更新个人信息
     *
     * @param account
     * @param personID
     * @param name
     * @param gender
     * @param university
     * @param faculty
     * @param role
     * @param password
     * @param img
     */
    @Transactional
    public void updateMyInfo(String account, String personID, String name, String gender, String university, String faculty, String role, String password, String img);

    /**
     * 创建新课程资料
     *
     * @param courseID
     * @param resourceName
     * @param resourceType
     * @param resourceIntro
     * @param resourceFile
     */
    @Transactional
    public void createNewResource(String courseID, String resourceName, String resourceType, String resourceIntro, String resourceFile, String account);


    /**
     * 更新课程资料信息
     *
     * @param resourceID
     * @param resourceName
     * @param resourceIntro
     * @param resourceFile
     */
    @Transactional
    public void updateResource(String resourceID, String resourceName, String resourceIntro, String resourceFile, String account);


    /**
     * 查看个人信息
     *
     * @param account
     * @return teacher
     */
    @Transactional
    public Teacher getMyInfo(String account);

    /**
     * 将教师从课程移除
     *
     * @param courseID
     * @param teacherTargetAccount
     */
    @Transactional
    public void removeTeacherFromCourse(String courseID, String teacherTargetAccount);


    /**
     * 将学生从课程移除
     *
     * @param courseID
     * @param studentTargetAccount
     */
    @Transactional
    public void removeStudentFromCourse(String courseID, String studentTargetAccount);


    /**
     * 催交作业
     *
     * @param studentID
     * @param taskID
     */
    @Transactional
    public void urgeStudentToSubmitTask(String studentID, String taskID, String courseID);


    /**
     * 上传资源
     *
     * @param questionImages
     * @param resourceID
     */
    public void updateResourceFile(MultipartFile[] questionImages, String resourceID);
}
