package com.cb.xourseparty.controller;

import com.cb.xourseparty.entity.*;
import com.cb.xourseparty.service.InfoService;
import com.cb.xourseparty.service.TeacherService;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class TeacherController {
    @Autowired
    private TeacherService teacherService;

    @Autowired
    private InfoService infoService;

    @PostMapping("/createAccountT")
    public void createAccountT(@RequestParam String account, @RequestParam String password, @RequestParam String name, @RequestParam String gender, @RequestParam String university, @RequestParam String faculty, @RequestParam String personID, @RequestParam String img, @RequestParam String role) {
        teacherService.createAccountT(account, password, name, gender, university, faculty, personID, img, role);
    }

    @PostMapping("/LoginT")
    public Teacher loginCallS(@RequestParam String account, @RequestParam String password) {
        return teacherService.loginCallT(account, password);
    }

    //    初始化主页
    @PostMapping("/Main/Teacher")
    public List<Course> initialIndexTeacherCall(@RequestParam String account) {
        List courses = teacherService.getTeacherJoinedCourses(account);
        return courses;
    }

    //    获得按学期分类的课程
    @PostMapping("/getCoursesSortedByTermT")
    public Map<String, List<Course>> getStudentJoinedCoursesByTerm(@RequestParam String account) {
        return teacherService.getTeacherJoinedCoursesByTerm(account);
    }

    //    获得最近的课程
    @PostMapping("/getRecentCoursesT")
    public List<Course> getRecentCoursesS(@RequestParam String account) {
        return teacherService.getTeacherRecentJoinedCourses(account);
    }


    //    新建课程
    @PostMapping("/CreateCourse")
    public void createNewCourseTeacherCall(@RequestParam String courseName, @RequestParam String courseTerm, @RequestParam String account) {
        teacherService.createNewCourse(courseName, courseTerm, account);
    }

    //    检查教师资料
    @PostMapping("/CheckTeacherT")
    public Teacher checkTeacherTeacherCall(String teacherAccount) {
        return infoService.getTeacherByAccount(teacherAccount);

    }

    //    加入课程
    @PostMapping("/JoinCourseT")
    public void joinCourseTeacherCall(@RequestParam String account, @RequestParam String courseCode) {
        teacherService.teacherJoinCourse(courseCode, account);
    }

    //    退出课程
    @PostMapping("/QuitCourseT")
    public void quitCourseTeacherCall(@RequestParam String account, @RequestParam String courseID) {
        teacherService.quitCourse(courseID, account);
    }

    //    查看课程的主页面=查看课程的作业列表
    @PostMapping("/TaskT")
    public List<Task> enterCourseTeacherCall(@RequestParam String courseID) {
        return infoService.getAllTasksByCourseID(courseID);
    }

    //    新建作业
    @PostMapping("/CreateTaskT")
    public void createNewTaskTeacherCall(@RequestParam String courseID, @RequestParam String taskName, @RequestParam String taskType, @RequestParam String taskDeadLine, @RequestParam String taskIntro, @RequestParam String taskFile, @RequestParam Integer taskTotalScore) {
        teacherService.createNewTask(courseID, taskName, taskType, taskDeadLine, taskIntro, taskFile, taskTotalScore);
    }

    //    查看班级基本信息
    @PostMapping("/ClasssInfoT")
    public Course getClasssInfoTeacherCall(@RequestParam String courseID) {
        return infoService.getCourseByID(courseID);
    }

    //    编辑课程班级信息
    @PostMapping("/UpdateClasssInfoT")
    public void updateCourseInfo(@RequestParam String courseID, @RequestParam String courseName, @RequestParam String courseTerm, @RequestParam String courseFaulty, @RequestParam String courseIntro) {
        teacherService.updateCourseInfo(courseID, courseName, courseTerm, courseFaulty, courseIntro);
    }

    //    查看班级教师ct
    @PostMapping("/ClasssTeachersT")
    public List<ClasssTeacher> getClasssTeachersTeacherCall(@RequestParam String courseID) {
        return infoService.getClasssTeachersByCourseID(courseID);
    }

    //    查看班级教师
    @PostMapping("/CoursesTeachersT")
    public List<Teacher> getCoursesTeachersByCourseID(@RequestParam String courseID) {
        return infoService.getCoursesTeachersByCourseID(courseID);
    }

    //    查看班级学生
    @PostMapping("/ClasssStudentsT")
    public List<Student> getClasssStudentsTeacherCall(@RequestParam String courseID) {
        return infoService.getClasssStudentsByCourseID(courseID);
    }

    //    删除教师
    @PostMapping("/RemoveTeacherFromCourseT")
    public void removeTeacherFromCourseTeacherCall(@RequestParam String teacherTargetAccount, @RequestParam String courseID) {
        teacherService.removeTeacherFromCourse(courseID, teacherTargetAccount);
    }

    //    删除学生
    @PostMapping("/RemoveStudentFromCourseT")
    public void removeStudentFromCourseTeacherCall(@RequestParam String studentTargetAccount, @RequestParam String courseID) {
        teacherService.removeStudentFromCourse(studentTargetAccount, courseID);
    }

    //    查看课程学生的作业情况
    @PostMapping("/ClasssGradeT")
    public Map<String, List<StudentTask>> getStudentsTasksByCourseTeacherCall(@RequestParam String courseID) {
        return infoService.getStudentsTasksByCourseID(courseID);
    }


    //    查看特定作业
    @PostMapping("/getTaskByIDT")
    public Task getTaskByIDS(@RequestParam String taskID) {
        return infoService.getTaskByID(taskID);
    }

    //    进入作业
    @PostMapping("/TaskDetailTeacherT")
    public List<StudentTask> getTaskDetailTeacherTeacherCall(@RequestParam String courseID, @RequestParam String taskID) {
        return infoService.getTaskDetailTeacher(courseID, taskID);
    }

    //    批改学生作业
    @PostMapping("/MarkTaskT")
    public void markStudentTaskTeacherCall(@RequestParam String studentTaskID, @RequestParam Integer grade, @RequestParam String account, @RequestParam String teacherComment) {
        teacherService.markStudentTask(studentTaskID, grade, account, teacherComment);
    }

    //    催交作业
    @PostMapping("/UrgeTaskT")
    public void urgeStudentToSubmitTaskTeacherCall(@RequestParam String studentID, @RequestParam String taskID, @RequestParam String courseID) {
        teacherService.urgeStudentToSubmitTask(studentID, taskID, courseID);
    }

    //    打回作业
    @PostMapping("/SendBackTaskT")
    public void sendBackTaskTeacherCall(@RequestParam String courseID, @RequestParam String taskID, @RequestParam String studentID, @RequestParam String studentTaskID) {
        teacherService.sendBackStudentTask(courseID, taskID, studentID, studentTaskID);
    }

    //    修改作业信息
    @PostMapping("/UpdateTaskInfoT")
    public void updateTaskInfoTeacherCall(@RequestParam String taskID, @RequestParam String taskName, @RequestParam String taskType, @RequestParam String taskDeadLine, @RequestParam String taskIntro, @RequestParam String taskFile, @RequestParam Integer taskTotalScore) {
        teacherService.updateTaskInfo(taskID, taskName, taskType, taskDeadLine, taskIntro, taskFile, taskTotalScore);
    }

    //更新作业文件
    @PostMapping(value = "/UpdateTaskFileT")
    public void updateTaskFile(String taskID, MultipartFile file, HttpServletRequest request) {
        if (file != null) {
            infoService.updateTaskFile(taskID, file, request);
        } else {
            System.out.println("上传错误");
        }
    }

    //    更新资源文件
    @PostMapping(value = "/UpdateResourceFileT")
    public void UpdateResourceFileT(String resourceID, MultipartFile file, HttpServletRequest request) {
        if (file != null) {
            infoService.UpdateResourceFileT(resourceID, file, request);
        } else {
            System.out.println("上传错误");
        }
    }

    //    下载作业说明文档
    @GetMapping("/downloadTask")
    public void downloadTask(@RequestParam String name, HttpServletResponse res) {
        infoService.downloadTaskFile(name, res);
    }

    //    下载学生作业说明文档
    @GetMapping("/downloadStudentTask")
    public void downloadStudentTask(@RequestParam String name, HttpServletResponse res) {
        infoService.downloadStudentTaskFile(name, res);
    }

    //    查看课程的资源列表
    @PostMapping("/ResourceT")
    public List<Resource> getAllResourcesByCourseTeacherCall(@RequestParam String courseID) {
        return infoService.getAllResourcesByCourse(courseID);
    }

    //    新建资源
    @PostMapping("/CreateResourceT")
    public void createResourceTeacherCall(@RequestParam String courseID, @RequestParam String resourceName, @RequestParam String resourceType, @RequestParam String resourceIntro, @RequestParam String resourceFile, String account) {
        teacherService.createNewResource(courseID, resourceName, resourceType, resourceIntro, resourceFile, account);
    }

    //    修改资源文档
    @PostMapping("/UpdateResourceT")
    public void updateResourceTeacherCall(@RequestParam String resourceID, @RequestParam String resourceName, @RequestParam String resourceIntro, @RequestParam String resourceFile, @RequestParam String account) {
        teacherService.updateResource(resourceID, resourceName, resourceIntro, resourceFile, account);
    }

    //    下载资源文档
    @GetMapping("/downloadResource")
    public void downloadResource(@RequestParam String name, HttpServletResponse res) {
        System.out.println("进入下载");
        infoService.downloadResource(name, res);
    }

    //    查看个人信息页
    @PostMapping("/MyInfoT")
    public Teacher getMyInfoTeacherCall(@RequestParam String account) {
        return teacherService.getMyInfo(account);
    }

    //    修改个人信息
    @PostMapping("/UpdateMyInfoT")
    public void updateMyInfoTeacherCall(@RequestParam String account, @RequestParam String personID, @RequestParam String name, @RequestParam String gender, @RequestParam String university, @RequestParam String faculty, @RequestParam String role, @RequestParam String password, @RequestParam String img) {
        teacherService.updateMyInfo(account, personID, name, gender, university, faculty, role, password, img);
    }

    @RequestMapping(value = "/downLoad", method = RequestMethod.GET)
    public static final String downLoad(String name, HttpServletRequest req, HttpServletResponse res) {
//        Map<String, Object> reMap = new HashMap<>();
//        String fileName = "aaa.txt";
//        String path = "E:\\University\\3\\javaEE\\workFinal\\xourseparty-2-EE\\src\\main\\java\\com\\cb\\xourseparty\\files\\resourceFile\\";
//        String filepath = path + fileName;
//        OutputStream os = null;
//        InputStream is = null;
//        try {
//            // 清空输出流
//            res.reset();
//            res.setCharacterEncoding("utf-8");
//            res.setContentType("application/octet-stream");
//            res.setHeader("Content-Disposition",
//                    "attachment;filename=" + new String(fileName.getBytes("UTF-8"), "ISO8859-1"));
//                // 读取流
//            File f = new File(filepath);
//            is = new FileInputStream(f);
//            if (is == null) {
//                reMap.put("msg", "下载附件失败");
//            }
//            ServletOutputStream sout = res.getOutputStream();
//            BufferedInputStream bis = null;
//            BufferedOutputStream bos = null;
//            bis = new BufferedInputStream(is);
//            bos = new BufferedOutputStream(sout);
//            byte[] buff = new byte[2048];
//            int bytesRead;
//            while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
//                bos.write(buff, 0, bytesRead);
//            }
//            bos.flush();
//            bos.close();
//            bis.close();
//            is.close();
//            os.close();
//        } catch (Exception e) {
//            reMap.put("msg", "下载附件失败,error:" + e.getMessage());
//        }
//
////        String str = JsonUtil.map2Json(reMap);
//        return "";
        Map<String, Object> reMap = new HashMap<>();
//文件名 可以通过形参传进来
        String fileName = name;
//要下载的文件地址 可以通过形参传进来
        String filepath = "E:\\University\\3\\javaEE\\workFinal\\xourseparty-2-EE\\src\\main\\java\\com\\cb\\xourseparty\\files\\resourceFile" + fileName;

        OutputStream os = null;
        InputStream is = null;
        try {
// 取得输出流
            os = res.getOutputStream();
// 清空输出流
            res.reset();
            res.setContentType("application/x-download;charset=GBK");
            res.setHeader("Content-Disposition",
                    "attachment;filename=" + new String(fileName.getBytes("utf-8"), "iso-8859-1"));
// 读取流
            File f = new File(filepath);
            is = new FileInputStream(f);
            if (is == null) {
                reMap.put("msg", "下载附件失败");
            }
// 复制
            IOUtils.copy(is, res.getOutputStream());
            res.getOutputStream().flush();
        } catch (IOException e) {
            reMap.put("msg", "下载附件失败,error:" + e.getMessage());
        }
// 文件的关闭放在finally中
        finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
            }
            try {
                if (os != null) {
                    os.close();
                }
            } catch (IOException e) {
            }
        }
//        String str = JsonUtil.map2Json(reMap);
        return "str";
    }

}
