package com.cb.xourseparty.service;

import com.cb.xourseparty.entity.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.List;
import java.util.Map;

/**
 *
 */
public interface StudentService {

    /**
     * 新建账户
     *
     * @param account
     * @param password
     * @param name
     * @param gender
     * @param executeClassID
     * @param faculty
     * @param personID
     * @param img
     * @param role
     */
    public void createAccountS(String account, String password, String name, String gender, String executeClassID, String faculty, String personID, String img, String role);


    /**
     * 登录
     *
     * @param account
     * @param password
     * @return
     */
    public Student loginCallS(String account, String password);

    /**
     * 获得所有加入的课程
     *
     * @param account
     * @return
     */
    @Transactional
    public List<Course> getStudentJoinedCourses(String account);


    /**
     * 获得按学期分类的课程
     *
     * @param account
     * @return
     */
    @Transactional
    public Map<String, List<Course>> getStudentJoinedCoursesByTerm(String account);

    /**
     * 获得最近的课程
     *
     * @param account
     * @return
     */
    @Transactional
    public List<Course> getStudentRecentJoinedCourses(String account);

    /**
     * 加入新课程
     *
     * @param courseCode
     * @param account
     */
    @Transactional
    public void studentJoinCourse(String courseCode, String account);

    /**
     * 退出课程
     *
     * @param courseID
     * @param account
     */
    @Transactional
    public void quitCourse(String courseID, String account);

    /**
     * 获得自己的所有作业
     *
     * @param account
     * @return
     */
    @Transactional
    public List<StudentTask> getAllMyStudentTasks(String account);

    /**
     * 获得自己的某门课程的所有作业
     *
     * @param courseID
     * @param account
     * @return
     */
    @Transactional
    public List<StudentTask> getMyStudentTasksByCourse(String courseID, String account);

    /**
     * 更新自己提交的作业
     *
     * @param account
     * @param taskID
     * @param courseID
     * @param file
     * @return
     */
    @Transactional
    public void updateMyTask(String account, String taskID, String courseID, String file);

    /**
     * 获得此学生的所有消息
     *
     * @param account
     * @return
     */
    @Transactional
    public List getAllNotices(String account);

    /**
     * 获得按课程分类的消息
     *
     * @param account
     * @return
     */
    @Transactional
    public Map<String, List<Notice>> getNoticesWithCourses(String account);

    /**
     * 阅读消息
     *
     * @param noticeID
     */
    @Transactional
    public void checkNotice(String noticeID);

    /**
     * 更新个人信息
     *
     * @param account        账户
     * @param name           姓名
     * @param password       密码
     * @param personID       个人ID
     * @param university     学校
     * @param executeClassID 行政班级
     * @param gender         性别
     * @param role           角色
     * @param img            头像
     */
    @Transactional
    public void updateMyInfo(String account, String personID, String name, String university, String executeClassID, String gender, String role, String password, String img);

    /**
     * 获得特定的作业
     *
     * @param taskID
     * @param account
     * @return 学生作业
     */
    public StudentTask getCertainStudentTaskByTaskID(String taskID, String account);


    /**
     * 获得个人信息
     *
     * @param account
     * @return student
     */
    @Transactional
    public Student getMyInfo(String account);

    /**
     * 检查是否有新消息
     *
     * @param account
     * @return
     */
    @Transactional
    public Boolean checkIsExistNewNotice(String account);
}
