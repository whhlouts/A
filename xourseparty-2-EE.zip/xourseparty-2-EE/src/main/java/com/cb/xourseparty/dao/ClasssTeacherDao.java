package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.ClasssTeacher;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;


@Mapper
@Component(value = "ClasssTeacherDao")
public interface ClasssTeacherDao {

    //    根据ID获得ClasssTeacher
    public ClasssTeacher getClasssTeacherByIDS(@Param("courseID") String courseID, @Param("teacherID") String teacherID);

    //    更新classsTeacher状态
    public void updateClasssTeacherStatue(ClasssTeacher classsTeacher);

    //    创建
    public void createNewClasssTeacher(ClasssTeacher classsTeacher);
}
