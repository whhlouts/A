package com.cb.xourseparty.service;

import com.cb.xourseparty.dao.*;
import com.cb.xourseparty.entity.*;
import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;


@Service
public class StudentServiceImpl implements StudentService {
    @Autowired
    private ClasssDao classsDao;
    @Autowired
    private ClasssTeacherDao classsTeacherDao;
    @Autowired
    private CourseDao courseDao;
    @Autowired
    private CourseStudentDao courseStudentDao;
    @Autowired
    private NoticeDao noticeDao;
    @Autowired
    private ResourceDao resourceDao;
    @Autowired
    private StudentDao studentDao;
    @Autowired
    private StudentTaskDao studentTaskDao;
    @Autowired
    private TaskDao taskDao;

    @Autowired
    private InfoService infoService;

    /**
     * 新建账户
     *
     * @param account
     * @param password
     * @param name
     * @param gender
     * @param executeClassID
     * @param faculty
     * @param personID
     * @param img
     * @param role
     */
    @Override
    public void createAccountS(String account, String password, String name, String gender, String executeClassID, String faculty, String personID, String img, String role) {
        studentDao.createAccountS(account, password, name, gender, executeClassID, faculty, personID, img, role);
    }

    /**
     * 登录
     *
     * @param account
     * @param password
     * @return
     */
    @Override
    public Student loginCallS(String account, String password) {
        return studentDao.loginCallS(account, password);
    }

    /**
     * 获得所有加入的课程
     *
     * @param account
     * @return
     */
    @Override
    public List<Course> getStudentJoinedCourses(String account) {
        List<Course> courses = studentDao.getAllJoinedCourses(account);
        return courses;
    }

    /**
     * 获得按学期分类的课程
     *
     * @param account
     * @return
     */
    @Override
    public Map<String, List<Course>> getStudentJoinedCoursesByTerm(String account) {
        List<Course> courses = studentDao.getAllJoinedCourses(account);
        Map<String, List<Course>> courseListMap = new LinkedHashMap<>();
        String[] terms = new String[10];
        for (Course course : courses) {
            String courseTerm = course.getCourseTerm();
//            int index = -1;
//            for (int i = 0; i < terms.length; i++) {
//                if (terms[i].equals(courseTerm)) {
//                    index = i;
//                }
//            }
//            if (index == -1) {
//                courseListMap.put(courseTerm, new ArrayList<>());
//                courseListMap.get(courseTerm).add(course);
//            } else {
//                courseListMap.get(courseTerm).add(course);
//            }
            if (courseListMap.get(courseTerm) == null) {
                courseListMap.put(courseTerm, new ArrayList<>());
                courseListMap.get(courseTerm).add(course);
            } else {
                courseListMap.get(courseTerm).add(course);
            }
        }
        return courseListMap;
    }

    /**
     * 获得最近的课程
     *
     * @param account
     * @return
     */
    @Override
    public List<Course> getStudentRecentJoinedCourses(String account) {
//        最近课程的显示数量
        int recentSize = 4;
        List<Course> recentCourses = new ArrayList<>();
        List<Course> courses = studentDao.getAllJoinedCourses(account);
        if (courses.size() <= recentSize) {
            return courses;
        } else {
            for (int i = 0; i < recentSize; i++) {
                recentCourses.add(courses.remove(courses.size() - 1));
            }
        }
        return recentCourses;
    }

    /**
     * 加入新课程
     *
     * @param courseCode
     * @param account
     */
    @Override
    public void studentJoinCourse(String courseCode, String account) {
//        Course course = courseDao.getCourseByCode(courseCode);
//        List<CourseStudent> courseStudents = courseStudentDao.getCourseStudentsByAccount(account);
//        for (CourseStudent courseStudent : courseStudents) {
//            if (courseStudent.getCourseID().equals(courseCode)) {
//                courseStudent.setQuited(false);
//                courseStudentDao.updateCourseStudentStatue(courseStudent);
//                return;
//            }
//        }
        Course course = courseDao.getCourseByCode(courseCode);
        CourseStudent courseStudentOld = courseStudentDao.getCourseStudentByIDS(course.getCourseID(), account);
        System.out.println(courseStudentOld);
        if (courseStudentOld == null) {
            String courseStudentID = "CS" + RandomStringUtils.randomAlphabetic(10);
            Date date = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            String joinDate = formatter.format(date);
            CourseStudent courseStudent = new CourseStudent(courseStudentID, account, course.getCourseID(), joinDate, false);
            studentDao.studentJoinCourse(courseStudent);

//        班级学生人数变化
            Classs classs = classsDao.getClasssByCourseID(course.getCourseID());
            classs.setCountStudent(classs.getCountStudent() + 1);
            classsDao.updateClasssInfo(classs);


            Student student = studentDao.getMyInfo(account);
            List<Task> tasks = taskDao.getAllTasks(course.getCourseID());
            for (Task task : tasks) {
                StudentTask studentTask = new StudentTask("ST" + RandomStringUtils.randomAlphabetic(10), "", "", 0.0, "type", "", false, account, student.getPersonID(), student.getName(), task.getTaskID(), task.getTaskName(), task.getTaskTotalScore(), task.getCourseID(), course.getCourseName(), false, 0, "", "", "");
                studentTaskDao.createNewStudentTask(studentTask);
            }
        } else {
            courseStudentOld.setQuited(false);
            courseStudentDao.updateCourseStudentStatue(courseStudentOld);
        }

        infoService.updateCourseNumber(course.getCourseID());
    }

    /**
     * 退出课程
     *
     * @param courseID
     * @param account
     */
    @Override
    public void quitCourse(String courseID, String account) {
        CourseStudent courseStudent = courseStudentDao.getCourseStudentByIDS(courseID, account);
        courseStudent.setQuited(true);
        studentDao.quitCourse(courseStudent);
        Classs classs = classsDao.getClasssByCourseID(courseID);
        classs.setCountStudent(classs.getCountStudent() - 1);
        classsDao.updateClasssInfo(classs);

        infoService.updateCourseNumber(courseID);
    }

    /**
     * 获得自己的所有作业
     *
     * @param account
     * @return
     */
    @Override
    public List<StudentTask> getAllMyStudentTasks(String account) {
        return studentTaskDao.getStudentTasksByStudentID(account);
    }

    /**
     * 获得自己的某门课程的所有作业
     *
     * @param courseID
     * @param account
     * @return
     */
    @Override
    public List<StudentTask> getMyStudentTasksByCourse(String courseID, String account) {
        return studentTaskDao.getCertainStudentsStudentTasksByCourseID(courseID, account);
    }

    /**
     * 更新自己提交的作业
     *
     * @param account
     * @param taskID
     * @param courseID
     * @param file
     * @return
     */
    @Override
    public void updateMyTask(String account, String taskID, String courseID, String file) {
//        这里还有一些问题需要更改，比如文件的大小
        StudentTask studentTask = getCertainStudentTaskByTaskID(taskID, account);
//        判断是否是第一次提交
        if (studentTask.getStudentTaskFile().equals("")) {
            Task task = taskDao.getTaskByTaskID(taskID);
            task.setTaskNumberHaveSubmit(task.getTaskNumberHaveSubmit() + 1);
            task.setTaskNumberNotYetSubmit(task.getTaskNumberNotYetSubmit() - 1);
            taskDao.updateTaskInfo(task);
        }
        studentTask.setStudentTaskFile(file);
        studentTask.setStudentTaskFileSize(0.0);
        studentTask.setStudentTaskFileType(file);
        studentTaskDao.updateStudentTask(studentTask);

        infoService.updateCourseNumber(courseID);
    }

    /**
     * 获得此学生的所有消息
     *
     * @param account
     * @return
     */
    @Override
    public List getAllNotices(String account) {
        return noticeDao.getNoticesByStudentID(account);
    }

    /**
     * 获得按课程分类的消息
     *
     * @param account
     * @return
     */
    @Override
    public Map<String, List<Notice>> getNoticesWithCourses(String account) {
        Map<String, List<Notice>> noticeListMap = new LinkedHashMap<>();
        List<Notice> notices = noticeDao.getNoticesByStudentID(account);
        for (Notice notice : notices) {
            Course course = courseDao.getCourseByID(notice.getCourseID());
            if (noticeListMap.get(course.getCourseName()) == null) {
                noticeListMap.put(course.getCourseName(), new ArrayList<>());
                noticeListMap.get(course.getCourseName()).add(notice);
            } else {
                noticeListMap.get(course.getCourseName()).add(notice);
            }
        }
        return noticeListMap;
    }

    /**
     * 阅读消息
     *
     * @param noticeID
     */
    @Override
    public void checkNotice(String noticeID) {
        Notice notice = noticeDao.getNoticeByNoticeID(noticeID);
        noticeDao.checkNotice(notice);
    }

    /**
     * 更新个人信息
     *
     * @param account        账户
     * @param personID       个人ID
     * @param name           姓名
     * @param university     学校
     * @param executeClassID 行政班级
     * @param gender         性别
     * @param role           角色
     * @param password       密码
     * @param img            头像
     */
    @Override
    public void updateMyInfo(String account, String personID, String name, String university, String executeClassID, String gender, String role, String password, String img) {
        Student newStudent = new Student(account, personID, name, gender, university, executeClassID, role, password, img);
        studentDao.updateMyInfo(newStudent);
    }

    /**
     * 获得特定的作业
     *
     * @param taskID
     * @param account
     * @return 学生作业
     */
    @Override
    public StudentTask getCertainStudentTaskByTaskID(String taskID, String account) {
        List<StudentTask> studentTasks = studentTaskDao.getStudentTasksByStudentID(account);
        StudentTask studentTask = new StudentTask();
        for (StudentTask st : studentTasks) {
            if (st.getTaskID().equals(taskID)) {
                studentTask = st;
            }
        }
        return studentTask;
    }

    /**
     * 获得个人信息
     *
     * @param account
     * @return student
     */
    @Override
    public Student getMyInfo(String account) {
        return studentDao.getMyInfo(account);
    }

    /**
     * 检查是否有新消息
     *
     * @param account
     * @return
     */
    @Override
    public Boolean checkIsExistNewNotice(String account) {
        List<Notice> notices = noticeDao.getNoticesByStudentID(account);
        for (Notice notice : notices) {
            if (notice.getChecked() == false) {
                return true;
            }
        }
        return false;
    }
//
//    private void updateTaskNumbers(String taskID) {
//        Task task = taskDao.getTaskByTaskID(taskID);
//
//        List<Student> students = courseDao.getCoursesStudents(task.getCourseID());
//
//        Integer numCoursesStudents = students.size();
//        task.setTaskNumberShouldSubmit(numCoursesStudents);
//
//        List<StudentTask> studentTasks = studentTaskDao.getSTsByCourseIDTaskID(taskID, task.getCourseID());
//
//        Integer numHaveSubmit = 0;
//        Integer numHaveChecked = 0;
//        for (StudentTask st : studentTasks) {
//            if (!st.getStudentTaskFile().equals("")) {
//                numHaveSubmit++;
//            }
//            if (st.getStudentTaskIsChecked()) {
//                numHaveChecked++;
//            }
//        }
//
//        task.setTaskNumberHaveSubmit(numHaveSubmit);
//        task.setTaskNumberHaveChecked(numHaveChecked);
//        task.setTaskNumberNotYetSubmit(numCoursesStudents - numHaveSubmit);
//        task.setTaskNumberNotYetChecked(numCoursesStudents - numHaveChecked);
//
//        taskDao.updateTaskInfo(task);
//    }
}
