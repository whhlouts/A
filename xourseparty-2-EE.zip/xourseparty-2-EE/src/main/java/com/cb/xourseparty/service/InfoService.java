package com.cb.xourseparty.service;

import com.cb.xourseparty.entity.*;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Map;

public interface InfoService {

    /**
     * 根据加课码获得课程
     *
     * @param courseCode
     * @return 课程
     */
    @Transactional
    public Course getCourseByCode(String courseCode);


    /**
     * 根据课程获得作业列表
     *
     * @param courseID
     * @return 作业列表
     */
    @Transactional
    public List<Task> getAllTasksByCourseID(String courseID);


    /**
     * 获得课程的资源列表
     *
     * @param courseID
     * @return 资源列表
     */
    @Transactional
    public List<Resource> getAllResourcesByCourse(String courseID);

    /**
     * 获得课程的教师
     *
     * @param courseID
     * @return
     */
    @Transactional
    public List<ClasssTeacher> getClasssTeachersByCourseID(String courseID);

    /**
     * 获得课程的教师
     *
     * @param courseID
     * @return
     */
    @Transactional
    public List<Teacher> getCoursesTeachersByCourseID(String courseID);

    /**
     * 获得课程的学生
     *
     * @param courseID
     * @return
     */
    @Transactional
    public List<Student> getClasssStudentsByCourseID(String courseID);


    /**
     * 根据ID获得课程
     *
     * @param courseID
     * @return
     */
    @Transactional
    public Course getCourseByID(String courseID);


    /**
     * 根据课程ID获得课程的学生们的作业
     *
     * @param courseID
     * @return Map
     */
    public Map<String, List<StudentTask>> getStudentsTasksByCourseID(String courseID);


    /**
     * 获得此作业的学生们的作业
     *
     * @param taskID
     * @param courseID
     * @return
     */
    public List<StudentTask> getTaskDetailTeacher(String courseID, String taskID);

    /**
     * 获得特定教师
     *
     * @param teacherAccount 教师的账户
     * @return 教师
     */
    public Teacher getTeacherByAccount(String teacherAccount);


    /**
     * 获得ClasssByCourseID
     *
     * @param courseID
     * @return
     */
    public Classs getClasssByCourseID(String courseID);

    /**
     * 获得Task
     *
     * @param taskID
     * @return
     */
    public Task getTaskByID(String taskID);

    /**
     * 更新作业数字
     *
     * @param taskID
     */
    public void updateTaskNumbers(String taskID);

    /**
     * 更新课程数字
     *
     * @param courseID
     */
    public void updateCourseNumber(String courseID);

    /**
     * 更新作业的文件
     *
     * @param taskID
     */
    public void updateTaskFile(String taskID, MultipartFile file, HttpServletRequest request);

    /**
     * 更新学生作业的文件
     *
     * @param studentTaskID
     */
    public void updateStudentTaskFile(String studentTaskID, MultipartFile file, HttpServletRequest request);

    /**
     * 更新资源的文件
     *
     * @param resourceID
     */
    public void UpdateResourceFileT(String resourceID, MultipartFile file, HttpServletRequest request);

    public void downloadResource(String name, HttpServletResponse res);

    public void downloadTaskFile(String name, HttpServletResponse res);

    public void downloadStudentTaskFile(String name, HttpServletResponse res);
}
