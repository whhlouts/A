package com.cb.xourseparty.entity;


/**
 * 课程类
 */
public class Course {

    private String courseID;
    private String courseName;
    private String courseIntro;
    private String courseUniversity;
    private String courseFaculty;
    private String courseTerm;
    private String courseType;//课程类型：必修课；选修课
    private String courseJoinCode;
    private String courseAdminID;
    private String courseAdminName;
    private String courseAdminImg;

    public Course(String courseID, String courseName, String courseIntro, String courseUniversity, String courseFaculty, String courseTerm, String courseType, String courseJoinCode, String courseAdminID, String courseAdminImg, String courseAdminName) {
        this.courseID = courseID;
        this.courseName = courseName;
        this.courseIntro = courseIntro;
        this.courseUniversity = courseUniversity;
        this.courseFaculty = courseFaculty;
        this.courseTerm = courseTerm;
        this.courseType = courseType;
        this.courseJoinCode = courseJoinCode;
        this.courseAdminID = courseAdminID;
        this.courseAdminImg = courseAdminImg;
        this.courseAdminName = courseAdminName;
    }

    public Course() {
    }

    public String getCourseAdminName() {
        return courseAdminName;
    }

    public void setCourseAdminName(String courseAdminName) {
        this.courseAdminName = courseAdminName;
    }

    public String getCourseAdminImg() {
        return courseAdminImg;
    }

    public void setCourseAdminImg(String courseAdminImg) {
        this.courseAdminImg = courseAdminImg;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseIntro() {
        return courseIntro;
    }

    public void setCourseIntro(String courseIntro) {
        this.courseIntro = courseIntro;
    }

    public String getCourseUniversity() {
        return courseUniversity;
    }

    public void setCourseUniversity(String courseUniversity) {
        this.courseUniversity = courseUniversity;
    }

    public String getCourseFaculty() {
        return courseFaculty;
    }

    public void setCourseFaculty(String courseFaculty) {
        this.courseFaculty = courseFaculty;
    }

    public String getCourseTerm() {
        return courseTerm;
    }

    public void setCourseTerm(String courseTerm) {
        this.courseTerm = courseTerm;
    }

    public String getCourseType() {
        return courseType;
    }

    public void setCourseType(String courseType) {
        this.courseType = courseType;
    }

    public String getCourseJoinCode() {
        return courseJoinCode;
    }

    public void setCourseJoinCode(String courseJoinCode) {
        this.courseJoinCode = courseJoinCode;
    }

    public String getCourseAdminID() {
        return courseAdminID;
    }

    public void setCourseAdminID(String courseAdminID) {
        this.courseAdminID = courseAdminID;
    }
}
