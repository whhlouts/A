package com.cb.xourseparty.entity;


/**
 * 通知类
 */
public class Notice {

    private String noticeID;
    private String noticeName;
    private String noticeType;// 催交，打回等等
    private String noticeContent;
    private String taskID;
    private String taskName;
    private String courseID;
    private String courseName;
    private String studentID;
    private Boolean isNoticeChecked;
    private String noticeCreateDate;

    public Notice(String noticeID, String noticeName, String noticeType, String noticeContent, String taskID, String taskName, String courseID, String courseName, String studentID, Boolean isNoticeChecked, String noticeCreateDate) {
        this.noticeID = noticeID;
        this.noticeName = noticeName;
        this.noticeType = noticeType;
        this.noticeContent = noticeContent;
        this.taskID = taskID;
        this.taskName = taskName;
        this.courseID = courseID;
        this.courseName = courseName;
        this.studentID = studentID;
        this.isNoticeChecked = isNoticeChecked;
        this.noticeCreateDate = noticeCreateDate;
    }


    public Notice() {
    }

    public String getNoticeID() {
        return noticeID;
    }

    public void setNoticeID(String noticeID) {
        this.noticeID = noticeID;
    }

    public String getNoticeName() {
        return noticeName;
    }

    public void setNoticeName(String noticeName) {
        this.noticeName = noticeName;
    }

    public String getNoticeType() {
        return noticeType;
    }

    public void setNoticeType(String noticeType) {
        this.noticeType = noticeType;
    }

    public String getNoticeContent() {
        return noticeContent;
    }

    public void setNoticeContent(String noticeContent) {
        this.noticeContent = noticeContent;
    }

    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public Boolean getChecked() {
        return isNoticeChecked;
    }

    public void setChecked(Boolean checked) {
        isNoticeChecked = checked;
    }

    public String getNoticeCreateDate() {
        return noticeCreateDate;
    }

    public void setNoticeCreateDate(String noticeCreateDate) {
        this.noticeCreateDate = noticeCreateDate;
    }
}
