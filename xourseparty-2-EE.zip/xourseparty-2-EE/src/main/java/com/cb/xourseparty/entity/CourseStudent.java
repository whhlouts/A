package com.cb.xourseparty.entity;

/***
 * CourseStudent类
 */
public class CourseStudent {

    private String courseStudentID;
    private String studentID;
    private String courseID;
    private String joinDate;
    private Boolean isQuited;// 是否已退课

    public CourseStudent(String courseStudentID, String studentID, String courseID, String joinDate,Boolean isQuited) {
        this.courseStudentID = courseStudentID;
        this.studentID = studentID;
        this.courseID = courseID;
        this.joinDate = joinDate;
        this.isQuited = isQuited;
    }

    public CourseStudent() {
    }

    public String getCourseStudentID() {
        return courseStudentID;
    }

    public void setCourseStudentID(String courseStudentID) {
        this.courseStudentID = courseStudentID;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getJoinDate() {
        return joinDate;
    }

    public void setJoinDate(String joinDate) {
        this.joinDate = joinDate;
    }

    public Boolean getQuited() {
        return isQuited;
    }

    public void setQuited(Boolean quited) {
        isQuited = quited;
    }
}
