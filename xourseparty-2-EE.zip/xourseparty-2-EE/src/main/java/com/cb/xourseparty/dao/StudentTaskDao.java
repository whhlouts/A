package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.StudentTask;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component(value = "StudentTaskDao")
public interface StudentTaskDao {

    //    根据StudentID获得所有作业
    public List<StudentTask> getStudentTasksByStudentID(@Param("studentID") String studentID);

    //    获得某人提交的本门课程的所有学生作业
    public List<StudentTask> getCertainStudentsStudentTasksByCourseID(@Param("courseID") String courseID, @Param("studentID") String studentID);

    //    更新学生提交的作业
    public void updateStudentTask(StudentTask studentTask);

    //    根据ID获得studentTask
    public StudentTask getStudentTaskByID(@Param("studentTaskID") String studentTaskID);

    //    新增studentTask
    public void createNewStudentTask(StudentTask studentTask);

    //    根据taskID和courseID获得StudentTAsks
    public List<StudentTask> getSTsByCourseIDTaskID(@Param("taskID") String taskID, @Param("courseID") String courseID);

}
