package com.cb.xourseparty.entity;

/**
 * 课程资源类
 */
public class Resource {

    private String resourceID;
    private String courseID;
    private String resourceName;
    private String resourceAuthor;
    private String resourceCreateDate;
    private String resourceIntro;
    private String resourceFile;
    private Integer resourceDownloadTimes;

    public Resource(String resourceID, String courseID, String resourceName, String resourceAuthor, String resourceCreateDate, String resourceIntro, String resourceFile, Integer resourceDownloadTimes) {
        this.resourceID = resourceID;
        this.courseID = courseID;
        this.resourceName = resourceName;
        this.resourceAuthor = resourceAuthor;
        this.resourceCreateDate = resourceCreateDate;
        this.resourceIntro = resourceIntro;
        this.resourceFile = resourceFile;
        this.resourceDownloadTimes = resourceDownloadTimes;
    }

    public Resource() {
    }

    public String getResourceID() {
        return resourceID;
    }

    public void setResourceID(String resourceID) {
        this.resourceID = resourceID;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public String getResourceAuthor() {
        return resourceAuthor;
    }

    public void setResourceAuthor(String resourceAuthor) {
        this.resourceAuthor = resourceAuthor;
    }

    public String getResourceCreateDate() {
        return resourceCreateDate;
    }

    public void setResourceCreateDate(String resourceCreateDate) {
        this.resourceCreateDate = resourceCreateDate;
    }

    public String getResourceIntro() {
        return resourceIntro;
    }

    public void setResourceIntro(String resourceIntro) {
        this.resourceIntro = resourceIntro;
    }

    public String getResourceFile() {
        return resourceFile;
    }

    public void setResourceFile(String resourceFile) {
        this.resourceFile = resourceFile;
    }

    public Integer getResourceDownloadTimes() {
        return resourceDownloadTimes;
    }

    public void setResourceDownloadTimes(Integer resourceDownloadTimes) {
        this.resourceDownloadTimes = resourceDownloadTimes;
    }
}
