package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.Classs;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;


@Mapper
@Component(value = "ClasssDao")
public interface ClasssDao {

    //    根据courseID获得Classs
    public Classs getClasssByCourseID(@Param("courseID") String courseID);

    //    创建course的同时生成classs
    public void createNewClasss(Classs classs);

    //    更新
    public void updateClasssInfo(Classs classs);
}
