package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.CourseStudent;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component(value = "CourseStudentDao")
public interface CourseStudentDao {
    //    根据课程信息和学生ID获得相应的CourseStudnet
    public CourseStudent getCourseStudentByIDS(@Param("courseID") String courseID, @Param("account") String account);

    //    更新courseStudent状态
    public void updateCourseStudentStatue(CourseStudent courseStudent);


    //    根据account获得所有相关的courseStudent
    public List<CourseStudent> getCourseStudentsByAccount(@Param("account") String account);
}
