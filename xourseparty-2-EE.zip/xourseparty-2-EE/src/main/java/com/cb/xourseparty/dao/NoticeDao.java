package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.Notice;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;


@Mapper
@Component(value = "NoticeDao")
public interface NoticeDao {

    //    获得此学生的所有消息
    public List getNoticesByStudentID(@Param("studentID") String studentID);

    //    获得特定消息
    public Notice getNoticeByNoticeID(@Param("noticeID") String noticeID);

    //    阅读消息
    public void checkNotice(Notice notice);

    //    新建消息
    public void createNotice(Notice notice);
}
