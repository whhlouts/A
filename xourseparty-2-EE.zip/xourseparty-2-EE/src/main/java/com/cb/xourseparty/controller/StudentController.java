package com.cb.xourseparty.controller;


import ch.qos.logback.core.net.SyslogOutputStream;
import com.cb.xourseparty.entity.*;
import com.cb.xourseparty.service.InfoService;
import com.cb.xourseparty.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
//@RequestMapping("/student")
//@CrossOrigin(allowCredentials = "true")
public class StudentController {

    @Autowired
    private StudentService studentService;

    @Autowired
    private InfoService infoService;

    @PostMapping("/createAccountS")
    public void createAccountT(@RequestParam String account, @RequestParam String password, @RequestParam String name, @RequestParam String gender, @RequestParam String university, @RequestParam String executeClassID, @RequestParam String personID, @RequestParam String img, @RequestParam String role) {
        studentService.createAccountS(account, password, name, gender, university, executeClassID, personID, img, role);
    }

    @PostMapping("/LoginS")
    public Student loginCallS(@RequestParam String account, @RequestParam String password) {
        return studentService.loginCallS(account, password);
    }

    //    初始化主页
    @PostMapping("/Main/Student")
    public List<Course> initialIndexStudentCall(@RequestParam String account) {
        return studentService.getStudentJoinedCourses(account);

    }

    //    获得按学期分类的课程
    @PostMapping("/getCoursesSortedByTermS")
    public Map<String, List<Course>> getStudentJoinedCoursesByTerm(@RequestParam String account) {
        return studentService.getStudentJoinedCoursesByTerm(account);
    }


    //    获得最近的课程
    @PostMapping("/getRecentCoursesS")
    public List<Course> getRecentCoursesS(@RequestParam String account) {
        return studentService.getStudentRecentJoinedCourses(account);
    }


    //    检查教师资料
    @PostMapping("/CheckTeacherS")
    public Teacher checkTeacherStudentCall(@RequestParam String teacherAccount) {
        return infoService.getTeacherByAccount(teacherAccount);

    }

    //    获得课程信息
    @PostMapping("/getCourseByIDS")
    public Course getCourseByIDS(@RequestParam String courseID) {
        return infoService.getCourseByID(courseID);
    }

    //    获得班级信息
    @PostMapping("/getClasssByCourseIDS")
    public Classs getClasssByCourseIDS(@RequestParam String courseID) {
        return infoService.getClasssByCourseID(courseID);
    }

    //    加入课程
    @PostMapping("/JoinCourseS")
    public void joinCourseStudentCall(@RequestParam String account, @RequestParam String courseCode) {
        studentService.studentJoinCourse(courseCode, account);
    }

    //    退出课程
    @PostMapping("/QuitCourseS")
    public void quitCourseStudentCall(@RequestParam String account, @RequestParam String courseID) {
        studentService.quitCourse(courseID, account);
    }

    //    查看课程的主页面=查看课程的作业列表
    @PostMapping("/TaskS")
    public List<Task> enterCourseStudentCall(@RequestParam String courseID) {
        return infoService.getAllTasksByCourseID(courseID);
    }

    //    查看个人作业信息
    @PostMapping("/TaskDetailStudentS")
    public StudentTask getTaskDetailStudentStudentCall(@RequestParam String taskID, @RequestParam String account) {
        return studentService.getCertainStudentTaskByTaskID(taskID, account);
    }

    //    查看特定作业
    @PostMapping("/getTaskByIDS")
    public Task getTaskByIDS(@RequestParam String taskID) {
        return infoService.getTaskByID(taskID);
    }

    //    下载作业说明文档

    //    更新作业
    @PostMapping("/UpdateMyTaskS")
    public void updateMyTaskStudentCall(@RequestParam String studentID, @RequestParam String taskID, @RequestParam String courseID, @RequestParam String file) {
        studentService.updateMyTask(studentID, taskID, courseID, file);
    }

    //    查看课程的资源列表
    @PostMapping("/ResourceS")
    public List<Resource> getAllResourcesByCourseStudentCall(@RequestParam String courseID) {
        return infoService.getAllResourcesByCourse(courseID);
    }

    //    查看班级教师ct
    @PostMapping("/ClasssTeachersS")
    public List<ClasssTeacher> getClasssTeachersStudentCall(@RequestParam String courseID) {
        return infoService.getClasssTeachersByCourseID(courseID);
    }

    //    查看班级教师
    @PostMapping("/CoursesTeachersS")
    public List<Teacher> getCoursesTeachersByCourseID(@RequestParam String courseID) {
        return infoService.getCoursesTeachersByCourseID(courseID);
    }

    //    查看班级学生
    @PostMapping("/ClasssStudentsS")
    public List<Student> getClasssStudentsStudentCall(@RequestParam String courseID) {
        return infoService.getClasssStudentsByCourseID(courseID);
    }

    //    查看班级基本信息
    @PostMapping("/ClasssInfoS")
    public Course getClasssInfoStudentCall(@RequestParam String courseID) {
        return infoService.getCourseByID(courseID);
    }

    //    查看个人成绩
    @PostMapping("ClasssGradeS")
    public List<StudentTask> getMyClasssGradeStudentCall(@RequestParam String account, @RequestParam String courseID) {
//        Map<String, List<Object>> map = new LinkedHashMap<>();
        List<StudentTask> studentTasksCourse = studentService.getMyStudentTasksByCourse(courseID, account);
//        List<Task> tasksCourse = infoService.getAllTasksByCourseID(courseID);
//
//        List<Task> tasks = new ArrayList<>();
//        List<StudentTask> studentTasks = new ArrayList<>();
//
//        for (StudentTask st : studentTasksCourse) {
//            String taskID = st.getTaskID();
//            for (Task t : tasksCourse) {
//                if (t.getTaskID().equals(taskID)) {
//                    tasks.add(t);
//                    studentTasks.add(st);
//                }
//            }
//        }
//        List[] lists = {tasks,studentTasks};
//        System.out.println(lists[1].size());
////        System.out.println(studentTasksAll.size());
        return studentTasksCourse;
    }

    //    查看个人信息页
    @PostMapping("/MyInfoS")
    public Student getMyInfoStudentCall(@RequestParam String account) {
        return studentService.getMyInfo(account);
    }

    //    修改个人信息
    @PostMapping("/UpdateMyInfoS")
    public void updateMyInfoStudentCall(@RequestParam String account, @RequestParam String personID, @RequestParam String name, @RequestParam String university, @RequestParam String executeClassID, @RequestParam String gender, @RequestParam String role, @RequestParam String password, @RequestParam String img) {
        studentService.updateMyInfo(account, personID, name, university, executeClassID, gender, role, password, img);
    }

    //    查看个人通知消息
    @PostMapping("/NoticeS")
    public Map<String, List<Notice>> getMyNoticesWithCoursesStudentCall(@RequestParam String account) {
        return studentService.getNoticesWithCourses(account);
    }

    //    阅读个人通知=>跳转
    @PostMapping("/CheckNoticeS")
    public void checkNoticeStudentCall(@RequestParam String noticeID) {
        studentService.checkNotice(noticeID);
    }

    //    检查是否有新消息
    @PostMapping("/checkIsExistNewNotice")
    public Boolean checkIsExistNewNotice(@RequestParam String account) {
        return studentService.checkIsExistNewNotice(account);
    }

    //更新作业文件
    @PostMapping(value = "/UpdateStudentTaskFileS")
    public void updateTaskFile(String studentTaskID, MultipartFile file, HttpServletRequest request) {
        if (file != null) {
            infoService.updateStudentTaskFile(studentTaskID, file, request);
        } else {
            System.out.println("上传错误");
        }
    }

}
