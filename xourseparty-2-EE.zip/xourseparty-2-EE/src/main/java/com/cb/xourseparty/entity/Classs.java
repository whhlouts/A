package com.cb.xourseparty.entity;

/**
 * 课程班级类
 */
public class Classs {
    private String classsID;
    private String courseID;
    private Integer countStudent;

    public Classs(String classsID, String courseID, Integer countStudent) {
        this.classsID = classsID;
        this.courseID = courseID;
        this.countStudent = countStudent;
    }

    public Classs() {
    }

    public String getClasssID() {
        return classsID;
    }

    public void setClasssID(String classsID) {
        this.classsID = classsID;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public Integer getCountStudent() {
        return countStudent;
    }

    public void setCountStudent(Integer countStudent) {
        this.countStudent = countStudent;
    }
}
