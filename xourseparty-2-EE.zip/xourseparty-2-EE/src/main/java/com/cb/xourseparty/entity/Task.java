package com.cb.xourseparty.entity;

/**
 * 作业类，包括作业的基本信息
 */
public class Task {

    private String taskID;
    private String courseID;
    private String taskName;
    private String taskIntro;
    private String taskType;
    private String taskCreateDate;
    private String taskDeadLine;
    private Integer taskNumberShouldSubmit;
    private Integer taskNumberHaveSubmit;
    private Integer taskNumberNotYetSubmit;
    private Integer taskNumberHaveChecked;
    private Integer taskNumberNotYetChecked;
    private String taskFile;
    private Integer taskTotalScore;


    public Task(String taskID, String courseID, String taskName, String taskIntro, String taskType, String taskCreateDate, String taskDeadLine, Integer taskNumberShouldSubmit, Integer taskNumberHaveSubmit, Integer taskNumberNotYetSubmit, Integer taskNumberHaveChecked, Integer taskNumberNotYetChecked, String taskFile, Integer taskTotalScore) {
        this.taskID = taskID;
        this.courseID = courseID;
        this.taskName = taskName;
        this.taskIntro = taskIntro;
        this.taskType = taskType;
        this.taskCreateDate = taskCreateDate;
        this.taskDeadLine = taskDeadLine;
        this.taskNumberShouldSubmit = taskNumberShouldSubmit;
        this.taskNumberHaveSubmit = taskNumberHaveSubmit;
        this.taskNumberNotYetSubmit = taskNumberNotYetSubmit;
        this.taskNumberHaveChecked = taskNumberHaveChecked;
        this.taskNumberNotYetChecked = taskNumberNotYetChecked;
        this.taskFile = taskFile;
        this.taskTotalScore = taskTotalScore;
    }

    public Task() {
    }

    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskIntro() {
        return taskIntro;
    }

    public void setTaskIntro(String taskIntro) {
        this.taskIntro = taskIntro;
    }

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType;
    }

    public String getTaskCreateDate() {
        return taskCreateDate;
    }

    public void setTaskCreateDate(String taskCreateDate) {
        this.taskCreateDate = taskCreateDate;
    }

    public String getTaskDeadLine() {
        return taskDeadLine;
    }

    public void setTaskDeadLine(String taskDeadLine) {
        this.taskDeadLine = taskDeadLine;
    }

    public Integer getTaskNumberShouldSubmit() {
        return taskNumberShouldSubmit;
    }

    public void setTaskNumberShouldSubmit(Integer taskNumberShouldSubmit) {
        this.taskNumberShouldSubmit = taskNumberShouldSubmit;
    }

    public Integer getTaskNumberHaveSubmit() {
        return taskNumberHaveSubmit;
    }

    public void setTaskNumberHaveSubmit(Integer taskNumberHaveSubmit) {
        this.taskNumberHaveSubmit = taskNumberHaveSubmit;
    }

    public Integer getTaskNumberNotYetSubmit() {
        return taskNumberNotYetSubmit;
    }

    public void setTaskNumberNotYetSubmit(Integer taskNumberNotYetSubmit) {
        this.taskNumberNotYetSubmit = taskNumberNotYetSubmit;
    }

    public Integer getTaskNumberHaveChecked() {
        return taskNumberHaveChecked;
    }

    public void setTaskNumberHaveChecked(Integer taskNumberHaveChecked) {
        this.taskNumberHaveChecked = taskNumberHaveChecked;
    }

    public Integer getTaskNumberNotYetChecked() {
        return taskNumberNotYetChecked;
    }

    public void setTaskNumberNotYetChecked(Integer taskNumberNotYetChecked) {
        this.taskNumberNotYetChecked = taskNumberNotYetChecked;
    }

    public String getTaskFile() {
        return taskFile;
    }

    public void setTaskFile(String taskFile) {
        this.taskFile = taskFile;
    }

    public Integer getTaskTotalScore() {
        return taskTotalScore;
    }

    public void setTaskTotalScore(Integer taskTotalScore) {
        this.taskTotalScore = taskTotalScore;
    }
}
