package com.cb.xourseparty.dao;

import com.cb.xourseparty.entity.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Mapper
@Component(value = "TeacherDao")
public interface TeacherDao {

    public void createAccountT(String account, String password, String name, String gender, String university, String faculty, String personID, String img, String role);

    //
    public Teacher loginCallT(String account, String password);

    //    获得教师加入的课程表
    public List<Course> getTeacherJoinedCoursesByTeacherID(@Param("teacherID") String teacherID);

    //    加入新课程
    public void teacherJoinCourse(ClasssTeacher classsTeacher);

    //    退出课程，可以通过加课码或者课程ID退出
    public void quitCourse(ClasssTeacher classsTeacher);

//    获得课程的学生成绩表
//    public Map<String, List<StudentTask>> getAllStudentsTasks(String courseID);

    //    更新个人信息，包括密码等
    public void updateMyInfo(Teacher teacher);

    //    获得教师的基本信息
    public Teacher getMyInfo(@Param("teacherID") String teacherID);

    //    获得教师的基本信息
    public Teacher getTeacherByID(@Param("teacherID") String teacherID);
}
