package com.cb.xourseparty.service;

import com.cb.xourseparty.dao.*;
import com.cb.xourseparty.entity.*;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.*;

@Service
public class InfoServiceImpl implements InfoService {

    @Autowired
    private TeacherDao teacherDao;
    @Autowired
    private StudentDao studentDao;
    @Autowired
    private ClasssDao classsDao;
    @Autowired
    private ClasssTeacherDao classsTeacherDao;
    @Autowired
    private CourseDao courseDao;
    @Autowired
    private CourseStudentDao courseStudentDao;
    @Autowired
    private NoticeDao noticeDao;
    @Autowired
    private ResourceDao resourceDao;
    @Autowired
    private StudentTaskDao studentTaskDao;
    @Autowired
    private TaskDao taskDao;

    /**
     * 根据code得到课程
     *
     * @param courseCode
     * @return 课程对象
     */
    @Override
    public Course getCourseByCode(String courseCode) {
        return courseDao.getCourseByCode(courseCode);
    }

    /**
     * 根据课程获得作业列表
     *
     * @param courseID
     * @return 作业列表
     */
    @Override
    public List<Task> getAllTasksByCourseID(String courseID) {
        return taskDao.getAllTasks(courseID);
    }

    /**
     * 获得课程的资源列表
     *
     * @param courseID
     * @return 资源列表
     */
    @Override
    public List<Resource> getAllResourcesByCourse(String courseID) {
        return resourceDao.getAllResources(courseID);
    }

    /**
     * 获得课程的教师ct
     *
     * @param courseID
     * @return
     */
    @Override
    public List<ClasssTeacher> getClasssTeachersByCourseID(String courseID) {
        return courseDao.getClasssTeachers(courseID);
    }

    /**
     * 获得课程的教师
     *
     * @param courseID
     * @return
     */
    @Override
    public List<Teacher> getCoursesTeachersByCourseID(String courseID) {
        return courseDao.getCoursesTeachers(courseID);
    }

    /**
     * 获得课程的学生
     *
     * @param courseID
     * @return
     */
    @Override
    public List<Student> getClasssStudentsByCourseID(String courseID) {
        return courseDao.getCoursesStudents(courseID);
    }

    /**
     * 根据ID获得课程
     *
     * @param courseID
     * @return 课程
     */
    @Override
    public Course getCourseByID(String courseID) {
        return courseDao.getCourseByID(courseID);
    }

    /**
     * 根据课程ID获得课程的学生们的作业
     *
     * @param courseID
     * @return Map
     */
    @Override
    public Map<String, List<StudentTask>> getStudentsTasksByCourseID(String courseID) {
        Map<String, List<StudentTask>> studentsTasksListMap = new LinkedHashMap<>();
        List<Student> students = courseDao.getCoursesStudents(courseID);
        System.out.println("studentsLength = " + students.size());
        for (Student student : students) {
            List<StudentTask> studentTasks = studentTaskDao.getStudentTasksByStudentID(student.getAccount());
            studentsTasksListMap.put(student.getPersonID() + "-" + student.getName(), studentTasks);
        }
//        if(studentsTasksListMap.size() == 0){
//            return null;
//        }
        return studentsTasksListMap;
    }

    /**
     * 获得此作业的学生们的作业
     *
     * @param courseID
     * @param taskID
     * @return
     */
    @Override
    public List<StudentTask> getTaskDetailTeacher(String courseID, String taskID) {
        List<StudentTask> studentTasksByCourseTask = studentTaskDao.getSTsByCourseIDTaskID(taskID, courseID);
//        Map<String, StudentTask> ssts = new LinkedHashMap<>();
//        for (StudentTask studentTask : studentTasksByCourseTask) {
//            Student student = studentDao.getMyInfo(studentTask.getStudentID());
////                studentTasks.add(studentTask);
//            ssts.put(student.getPersonID() + "-" + student.getName(), studentTask);
//        }
//        System.out.println(ssts.size());
        return studentTasksByCourseTask;
    }

    /**
     * 获得特定教师
     *
     * @param teacherAccount 教师的账户
     * @return 教师
     */
    @Override
    public Teacher getTeacherByAccount(String teacherAccount) {
        return teacherDao.getTeacherByID(teacherAccount);
    }

    /**
     * 获得ClasssByCourseID
     *
     * @param courseID
     * @return
     */
    @Override
    public Classs getClasssByCourseID(String courseID) {
        return classsDao.getClasssByCourseID(courseID);
    }

    /**
     * 获得Task
     *
     * @param taskID
     * @return
     */
    @Override
    public Task getTaskByID(String taskID) {
        return taskDao.getTaskByTaskID(taskID);
    }

    /**
     * 更新数字
     *
     * @param taskID
     */
    @Override
    public void updateTaskNumbers(String taskID) {
        Task task = taskDao.getTaskByTaskID(taskID);
        List<Student> students = courseDao.getCoursesStudents(task.getCourseID());
        Integer numCoursesStudents = students.size();
        task.setTaskNumberShouldSubmit(numCoursesStudents);
        List<StudentTask> studentTasks = studentTaskDao.getSTsByCourseIDTaskID(taskID, task.getCourseID());
        Integer numHaveSubmit = 0;
        Integer numHaveChecked = 0;
        for (StudentTask st : studentTasks) {
            if (!st.getStudentTaskFile().equals("")) {
                numHaveSubmit++;
            }
            if (st.getStudentTaskIsChecked()) {
                numHaveChecked++;
            }
        }

        task.setTaskNumberHaveSubmit(numHaveSubmit);
        task.setTaskNumberHaveChecked(numHaveChecked);
        task.setTaskNumberNotYetSubmit(numCoursesStudents - numHaveSubmit);
        task.setTaskNumberNotYetChecked(numCoursesStudents - numHaveChecked);

        taskDao.updateTaskInfo(task);
    }

    /**
     * 更新课程数字
     *
     * @param courseID
     */
    @Override
    public void updateCourseNumber(String courseID) {
        List<Task> tasks = taskDao.getAllTasks(courseID);

        for (Task task : tasks) {
            updateTaskNumbers(task.getTaskID());
        }
    }

    /**
     * 更新作业的文件
     *
     * @param taskID
     */
    @Override
    public void updateTaskFile(String taskID, MultipartFile file, HttpServletRequest request) {
        try {
            System.out.println("taskID" + taskID);
            System.out.println("file" + file.getName());
            System.out.println("Request" + request.getAuthType());
            String oldName = file.getOriginalFilename();
            String realPath = "E:\\University\\3\\javaEE\\workFinal\\xourseparty-2-EE\\src\\main\\java\\com\\cb\\xourseparty\\files\\taskExplainFile\\";
            String newName = UUID.randomUUID().toString() + "_" + oldName;
            File folder = new File(realPath, newName);
            if (!folder.exists()) {
                folder.mkdirs();
            }
            file.transferTo(folder);

            Task task = taskDao.getTaskByTaskID(taskID);
            task.setTaskFile(newName);
            taskDao.updateTaskInfo(task);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    /**
     * 更新学生作业的文件
     *
     * @param studentTaskID
     * @param file
     * @param request
     */
    @Override
    public void updateStudentTaskFile(String studentTaskID, MultipartFile file, HttpServletRequest request) {
        try {
            System.out.println("stID" + studentTaskID);
            System.out.println("file" + file.getName());
            System.out.println("Request" + request.getAuthType());
            String oldName = file.getOriginalFilename();
            String realPath = "E:\\University\\3\\javaEE\\workFinal\\xourseparty-2-EE\\src\\main\\java\\com\\cb\\xourseparty\\files\\studentTaskFile\\";
            String newName = UUID.randomUUID().toString() + "_" + oldName;
            File folder = new File(realPath, newName);
            if (!folder.exists()) {
                folder.mkdirs();
            }
            file.transferTo(folder);

            StudentTask studentTask = studentTaskDao.getStudentTaskByID(studentTaskID);
            studentTask.setStudentTaskName(oldName);
            studentTask.setStudentTaskFile(newName);
            studentTaskDao.updateStudentTask(studentTask);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 更新资源的文件
     *
     * @param resourceID
     * @param file
     * @param request
     */
    @Override
    public void UpdateResourceFileT(String resourceID, MultipartFile file, HttpServletRequest request) {
        try {
            System.out.println("stID" + resourceID);
            System.out.println("file" + file.getName());
            System.out.println("Request" + request.getAuthType());
            String oldName = file.getOriginalFilename();
            String realPath = "E:\\University\\3\\javaEE\\workFinal\\xourseparty-2-EE\\src\\main\\java\\com\\cb\\xourseparty\\files\\resourceFile\\";
            String newName = UUID.randomUUID().toString() + "_" + oldName;
            File folder = new File(realPath, newName);
            if (!folder.exists()) {
                folder.mkdirs();
            }
            file.transferTo(folder);

            Resource resource = resourceDao.getResourceByID(resourceID);
            resource.setResourceFile(newName);
            resource.setResourceName(oldName);
            resourceDao.updateResource(resource);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void downloadResource(String name, HttpServletResponse res) {
        String type = "resource";
        downloadFile(name, type, res);
    }

    @Override
    public void downloadTaskFile(String name, HttpServletResponse res) {
        String type = "taskExplain";
        downloadFile(name, type, res);

    }

    @Override
    public void downloadStudentTaskFile(String name, HttpServletResponse res) {
        String type = "studentTask";
        downloadFile(name, type, res);
    }

    private void downloadFile(String name, String type, HttpServletResponse res) {
        String downloadFilePath = "E:\\University\\3\\javaEE\\workFinal\\xourseparty-2-EE\\src\\main\\java\\com\\cb\\xourseparty\\files\\";//被下载的文件在服务器中的路径,
        if (type.equals("studentTask")) {
            downloadFilePath += "studentTaskFile\\" + name;
        } else if (type.equals("resource")) {
            downloadFilePath += "resourceFile\\" + name;
        } else {
            downloadFilePath += "taskExplainFile\\" + name;
        }
//        String fileName = name;//被下载文件的名称
//        File file = new File(downloadFilePath);
//        if (file.exists()) {
//            res.setContentType("application/force-download");// 设置强制下载不打开
//            res.addHeader("Content-Disposition", "attachment;fileName=" + fileName);
//            byte[] buffer = new byte[1024];
//            FileInputStream fis = null;
//            BufferedInputStream bis = null;
//            try {
//                fis = new FileInputStream(file);
//                bis = new BufferedInputStream(fis);
//                OutputStream outputStream = res.getOutputStream();
//                int i = bis.read(buffer);
//                while (i != -1) {
//                    outputStream.write(buffer, 0, i);
//                    i = bis.read(buffer);
//                }
////                return "下载成功";
//            } catch (Exception e) {
//                e.printStackTrace();
//            } finally {
//                if (bis != null) {
//                    try {
//                        bis.close();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//                if (fis != null) {
//                    try {
//                        fis.close();
//                    } catch (IOException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        }
        Map<String, Object> reMap = new HashMap<>();
//文件名 可以通过形参传进来
        String fileName = name;
//要下载的文件地址 可以通过形参传进来
        String filepath = "E:\\University\\3\\javaEE\\workFinal\\xourseparty-2-EE\\src\\main\\java\\com\\cb\\xourseparty\\files\\resourceFile" + fileName;

        OutputStream os = null;
        InputStream is = null;
        try {
// 取得输出流
            os = res.getOutputStream();
// 清空输出流
            res.reset();
            res.setContentType("application/x-download;charset=GBK");
            res.setHeader("Content-Disposition",
                    "attachment;filename=" + new String(fileName.getBytes("utf-8"), "iso-8859-1"));
// 读取流
            File f = new File(filepath);
            is = new FileInputStream(f);
            if (is == null) {
                reMap.put("msg", "下载附件失败");
            }
// 复制
            IOUtils.copy(is, res.getOutputStream());
            res.getOutputStream().flush();
        } catch (IOException e) {
            reMap.put("msg", "下载附件失败,error:" + e.getMessage());
        }
// 文件的关闭放在finally中
        finally {
            try {
                if (is != null) {
                    is.close();
                }
            } catch (IOException e) {
            }
            try {
                if (os != null) {
                    os.close();
                }
            } catch (IOException e) {
            }
        }
//        String str = JsonUtil.map2Json(reMap);
    }


}
