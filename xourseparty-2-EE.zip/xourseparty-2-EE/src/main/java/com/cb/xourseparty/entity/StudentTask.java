package com.cb.xourseparty.entity;

/**
 * 学生作业类，包含学生提交的作业的相关信息
 */
public class StudentTask {

    private String studentTaskID;
    private String studentTaskName;
    private String studentTaskFile;
    private Double studentTaskFileSize;
    private String studentTaskFileType;
    private String studentTaskUpdateTime;
    private Boolean studentTaskIsChecked;
    private String studentID;
    private String studentPersonID;
    private String studentName;
    private String taskID;
    private String taskName;
    private Integer taskTotalGrade;
    private String courseID;
    private String courseName;
    private Boolean studentTaskIsSentBack;
    private Integer studentTaskGrade;
    private String teacherComment;
    private String markerTeacherID;
    private String markerTeacherName;


    public StudentTask(String studentTaskID, String studentTaskName, String studentTaskFile, Double studentTaskFileSize, String studentTaskFileType, String studentTaskUpdateTime, Boolean studentTaskIsChecked, String studentID,String studentPersonID,String studentName, String taskID, String taskName, Integer taskTotalGrade, String courseID, String courseName, Boolean studentTaskIsSentBack, Integer studentTaskGrade, String teacherComment, String markerTeacherID, String markerTeacherName) {
        this.studentTaskID = studentTaskID;
        this.studentTaskName = studentTaskName;
        this.studentTaskFile = studentTaskFile;
        this.studentTaskFileSize = studentTaskFileSize;
        this.studentTaskFileType = studentTaskFileType;
        this.studentTaskUpdateTime = studentTaskUpdateTime;
        this.studentTaskIsChecked = studentTaskIsChecked;
        this.studentID = studentID;
        this.studentPersonID = studentPersonID;
        this.studentName = studentName;
        this.taskID = taskID;
        this.taskName = taskName;
        this.taskTotalGrade = taskTotalGrade;
        this.courseID = courseID;
        this.courseName = courseName;
        this.studentTaskIsSentBack = studentTaskIsSentBack;
        this.studentTaskGrade = studentTaskGrade;
        this.teacherComment = teacherComment;
        this.markerTeacherID = markerTeacherID;
        this.markerTeacherName = markerTeacherName;
    }

    public String getStudentPersonID() {
        return studentPersonID;
    }

    public void setStudentPersonID(String studentPersonID) {
        this.studentPersonID = studentPersonID;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public Integer getTaskTotalGrade() {
        return taskTotalGrade;
    }

    public void setTaskTotalGrade(Integer taskTotalGrade) {
        this.taskTotalGrade = taskTotalGrade;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getMarkerTeacherName() {
        return markerTeacherName;
    }

    public void setMarkerTeacherName(String markerTeacherName) {
        this.markerTeacherName = markerTeacherName;
    }

    public StudentTask() {
    }

    public String getStudentTaskID() {
        return studentTaskID;
    }

    public void setStudentTaskID(String studentTaskID) {
        this.studentTaskID = studentTaskID;
    }

    public String getStudentTaskName() {
        return studentTaskName;
    }

    public void setStudentTaskName(String studentTaskName) {
        this.studentTaskName = studentTaskName;
    }

    public String getStudentTaskFile() {
        return studentTaskFile;
    }

    public void setStudentTaskFile(String studentTaskFile) {
        this.studentTaskFile = studentTaskFile;
    }

    public Double getStudentTaskFileSize() {
        return studentTaskFileSize;
    }

    public void setStudentTaskFileSize(Double studentTaskFileSize) {
        this.studentTaskFileSize = studentTaskFileSize;
    }

    public String getStudentTaskFileType() {
        return studentTaskFileType;
    }

    public void setStudentTaskFileType(String studentTaskFileType) {
        this.studentTaskFileType = studentTaskFileType;
    }

    public String getStudentTaskUpdateTime() {
        return studentTaskUpdateTime;
    }

    public void setStudentTaskUpdateTime(String studentTaskUpdateTime) {
        this.studentTaskUpdateTime = studentTaskUpdateTime;
    }

    public Boolean getStudentTaskIsChecked() {
        return studentTaskIsChecked;
    }

    public void setStudentTaskIsChecked(Boolean studentTaskIsChecked) {
        this.studentTaskIsChecked = studentTaskIsChecked;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getTaskID() {
        return taskID;
    }

    public void setTaskID(String taskID) {
        this.taskID = taskID;
    }

    public String getCourseID() {
        return courseID;
    }

    public void setCourseID(String courseID) {
        this.courseID = courseID;
    }

    public Boolean getStudentTaskIsSentBack() {
        return studentTaskIsSentBack;
    }

    public void setStudentTaskIsSentBack(Boolean studentTaskIsSentBack) {
        this.studentTaskIsSentBack = studentTaskIsSentBack;
    }

    public Integer getStudentTaskGrade() {
        return studentTaskGrade;
    }

    public void setStudentTaskGrade(Integer studentTaskGrade) {
        this.studentTaskGrade = studentTaskGrade;
    }

    public String getTeacherComment() {
        return teacherComment;
    }

    public void setTeacherComment(String teacherComment) {
        this.teacherComment = teacherComment;
    }

    public String getMarkerTeacherID() {
        return markerTeacherID;
    }

    public void setMarkerTeacherID(String markerTeacherID) {
        this.markerTeacherID = markerTeacherID;
    }
}
