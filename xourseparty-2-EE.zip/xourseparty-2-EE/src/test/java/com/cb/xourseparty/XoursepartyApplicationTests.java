package com.cb.xourseparty;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XoursepartyApplicationTests {

    @Test
    void contextLoads() {
    }

}
